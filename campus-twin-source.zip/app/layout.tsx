import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'校园数字孪生 | Campus Twin',description:'可交互的 Three.js 校园数字孪生演示平台'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body>{children}</body></html>;}

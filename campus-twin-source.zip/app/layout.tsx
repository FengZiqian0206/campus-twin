import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'赛马会创新楼 | PolyU Architecture',description:'香港理工大学赛马会创新楼风格化建筑模型'};
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){return <html lang="zh-CN"><body>{children}</body></html>;}


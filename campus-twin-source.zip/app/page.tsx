'use client';
import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Building2, Layers3, RotateCcw, ArrowUp, Maximize, Eye, Box, Activity, Zap, Users, ChevronRight, Compass, GraduationCap } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
const buildings = [
{id:'A01',name:'图书馆',type:'公共服务',x:0,z:-9,w:17,d:12,h:16,floors:5,area:8600,people:426,color:'#4be2ca'},
{id:'A02',name:'第一教学楼',type:'教学科研',x:-29,z:-27,w:18,d:11,h:14,floors:4,area:7200,people:612,color:'#68b7ed'},
{id:'A03',name:'第二教学楼',type:'教学科研',x:-29,z:-7,w:18,d:11,h:14,floors:4,area:7200,people:508,color:'#68b7ed'},
{id:'A04',name:'实验中心',type:'教学科研',x:27,z:-27,w:17,d:12,h:19,floors:6,area:9600,people:286,color:'#68b7ed'},
{id:'A05',name:'行政楼',type:'公共服务',x:0,z:-32,w:15,d:9,h:12,floors:4,area:4200,people:132,color:'#4be2ca'},
{id:'B01',name:'学生公寓 1 栋',type:'生活配套',x:-30,z:19,w:11,d:18,h:22,floors:7,area:8100,people:364,color:'#b1a2f3'},
{id:'B02',name:'学生公寓 2 栋',type:'生活配套',x:-13,z:24,w:11,d:18,h:22,floors:7,area:8100,people:392,color:'#b1a2f3'},
{id:'B03',name:'校园餐厅',type:'生活配套',x:9,z:26,w:17,d:11,h:8,floors:2,area:3200,people:248,color:'#b1a2f3'},
{id:'C01',name:'体育馆',type:'运动场所',x:31,z:-5,w:16,d:13,h:10,floors:2,area:4600,people:86,color:'#edbc70'},
];
type Building = typeof buildings[number];
type SceneAPI = {select:(id:string)=>void;view:(top?:boolean)=>void;zoom:(n:number)=>void;night:(v:boolean)=>void;labels:(v:boolean)=>void;rotate:(v:boolean)=>void};
function CampusScene({onSelect,api}:{onSelect:(b:Building)=>void;api:React.RefObject<SceneAPI|null>}){
 const host=useRef<HTMLDivElement>(null);const [error,setError]=useState(false);
 useEffect(()=>{
 const container=host.current!;let renderer:THREE.WebGLRenderer;
 try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});}catch{setError(true);return;}
 renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;container.appendChild(renderer.domElement);
 const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(42,1,.1,600);camera.position.set(105,110,130);
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.minDistance=35;controls.maxDistance=260;controls.maxPolarAngle=Math.PI/2.12;controls.autoRotateSpeed=.5;
 const ambient=new THREE.HemisphereLight('#d5f4ff','#354453',2.5);scene.add(ambient);
 const sun=new THREE.DirectionalLight('#e3f3ff',3);sun.position.set(-40,90,50);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-90,right:90,top:90,bottom:-90});sun.shadow.bias=-.001;scene.add(sun);
 const meshes:THREE.Mesh[]=[];const labels:{el:HTMLButtonElement;pos:THREE.Vector3}[]=[];
 const box=(w:number,h:number,d:number,x:number,y:number,z:number,color:string)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color,roughness:.65,metalness:.1}));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;scene.add(m);return m;};
 box(99,2,92,0,-1.5,0,'#263d47');box(97,.4,90,0,-.3,0,'#36524f');const grid=new THREE.GridHelper(300,60,'#284252','#203342');grid.position.y=-2.6;scene.add(grid);
 [-41,42,9].forEach(z=>box(95,.12,4,0,0,z,'#263540'));[-43,42].forEach(x=>box(4,.12,86,x,0,0,'#263540'));
 for(let x=-42;x<45;x+=7){box(2,.14,.13,x,.1,9,'#799593');box(2,.14,.13,x,.1,42,'#799593');}
 box(19,.18,10,0,.1,2,'#69827f');const fountain=new THREE.Mesh(new THREE.CylinderGeometry(3.1,3.1,.5,40),new THREE.MeshStandardMaterial({color:'#49c6c1',metalness:.5,roughness:.1}));fountain.position.set(0,.6,2);scene.add(fountain);
 buildings.forEach(b=>{const m=box(b.w,b.h,b.d,b.x,b.h/2,b.z,b.color);m.userData.building=b;meshes.push(m);
 m.add(new THREE.LineSegments(new THREE.EdgesGeometry(m.geometry),new THREE.LineBasicMaterial({color:b.color,transparent:true,opacity:.65})));
 box(b.w+.8,.5,b.d+.8,b.x,b.h+.1,b.z,'#c0d9d9');box(b.w*.55,.8,b.d*.55,b.x,b.h+.7,b.z,'#607f87');
 for(let f=1;f<b.floors;f++)box(b.w+.06,.45,b.d+.06,b.x,f*3,b.z,'#365566');
 for(let x=-b.w/2+1.4;x<b.w/2;x+=2.4)box(.7,b.h-1,.09,b.x+x,b.h/2,b.z+b.d/2+.05,'#9cd3d9');
 const el=document.createElement('button');el.className='map-label';el.textContent=b.name;el.setAttribute('aria-label','查看'+b.name);el.onclick=()=>{api.current?.select(b.id);onSelect(b);};container.appendChild(el);labels.push({el,pos:new THREE.Vector3(b.x,b.h+3,b.z)});
 });
 box(20,.2,24,30,.2,25,'#8e6865');box(15,.22,19,30,.3,25,'#448c79');[17,33].forEach(z=>box(13,.05,.15,30,.45,z,'#cadbd1'));[23.5,36.5].forEach(x=>box(.15,.05,16,x,.45,25,'#cadbd1'));box(13,.05,.15,30,.45,25,'#cadbd1');
 const ring=new THREE.Mesh(new THREE.RingGeometry(2.5,2.65,40),new THREE.MeshBasicMaterial({color:'#cadbd1',side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.set(30,.46,25);scene.add(ring);
 const tree=(x:number,z:number)=>{box(.35,2,.35,x,1,z,'#796e57');const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.6,1),new THREE.MeshStandardMaterial({color:'#428d76',roughness:1}));crown.position.set(x,3,z);crown.castShadow=true;scene.add(crown);};for(let n=-36;n<=36;n+=6){tree(n,39);tree(n,-38);tree(-39,n);tree(39,n);}[-21,17].forEach(x=>[-17,-11,0,17,30].forEach(z=>tree(x,z)));
 const highlight=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshBasicMaterial({color:'#5fffe0',transparent:true,opacity:.16,depthWrite:false}));scene.add(highlight);let destination:THREE.Vector3|null=null;
 api.current={select(id){const b=buildings.find(b=>b.id===id);if(!b)return;highlight.scale.set(b.w+1.3,b.h+1.5,b.d+1.3);highlight.position.set(b.x,b.h/2,b.z);labels.forEach(l=>l.el.classList.toggle('selected',l.el.textContent===b.name));},view(top=false){destination=top?new THREE.Vector3(0,160,.1):new THREE.Vector3(105,110,130);},zoom(n){camera.position.sub(controls.target).multiplyScalar(n).clampLength(35,260).add(controls.target);},night(v){ambient.intensity=v?.7:2.5;sun.intensity=v?.6:3;},labels(v){labels.forEach(l=>l.el.hidden=!v);},rotate(v){controls.autoRotate=v;}};api.current.select('A01');
 const raycaster=new THREE.Raycaster();const pointer=new THREE.Vector2();let dx=0,dy=0;const down=(e:PointerEvent)=>{dx=e.clientX;dy=e.clientY;};const up=(e:PointerEvent)=>{if(Math.hypot(e.clientX-dx,e.clientY-dy)>5)return;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects(meshes,false)[0];if(hit){const b=hit.object.userData.building;api.current?.select(b.id);onSelect(b);}};renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointerup',up);
 const resize=new ResizeObserver(()=>{const w=container.clientWidth,h=container.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();});resize.observe(container);
 let frame=0;const animate=()=>{frame=requestAnimationFrame(animate);if(destination){camera.position.lerp(destination,.07);controls.target.lerp(new THREE.Vector3(),.07);if(camera.position.distanceTo(destination)<.2)destination=null;}controls.update();renderer.render(scene,camera);labels.forEach(l=>{const p=l.pos.clone().project(camera);l.el.style.left=(p.x*.5+.5)*container.clientWidth+'px';l.el.style.top=(-p.y*.5+.5)*container.clientHeight+'px';l.el.style.visibility=p.z>1?'hidden':'visible';});};animate();
 return()=>{cancelAnimationFrame(frame);resize.disconnect();controls.dispose();renderer.dispose();scene.traverse(o=>{if(o instanceof THREE.Mesh||o instanceof THREE.LineSegments){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose());}});renderer.domElement.remove();labels.forEach(l=>l.el.remove());api.current=null;};
 },[api,onSelect]);
 return <div ref={host} className="scene" aria-label="可交互三维校园模型">{error&&<div className="webgl-error">无法启动三维视图，请使用支持 WebGL 的浏览器并开启硬件加速。建筑信息仍可从左侧查看。</div>}</div>;
}
export default function Home(){
 const [selected,setSelected]=useState(buildings[0]);const [night,setNight]=useState(false);const [labels,setLabels]=useState(true);const [rotate,setRotate]=useState(false);const api=useRef<SceneAPI|null>(null);
 const select=(b:Building)=>{setSelected(b);api.current?.select(b.id);};
 useEffect(()=>{
  const context=(document as Document & {modelContext?:{registerTool:(tool:unknown,options:{signal:AbortSignal})=>void|Promise<void>}}).modelContext;
  if(!context?.registerTool)return;
  const lifecycle=new AbortController();
  const tool={name:'select_campus_building',title:'查看校园建筑',description:'选择校园建筑并显示其模拟运行信息。',inputSchema:{type:'object',properties:{id:{type:'string',enum:buildings.map(b=>b.id)}},required:['id'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},async execute(input:unknown){const id=(input as {id?:unknown})?.id;const b=buildings.find(b=>b.id===id);if(!b)throw new Error('建筑编号无效');setSelected(b);api.current?.select(b.id);await new Promise<void>(resolve=>requestAnimationFrame(()=>resolve()));return {id:b.id,name:b.name,area:b.area,people:b.people,simulated:true};}};
  try{void Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}
  return()=>lifecycle.abort();
 },[]);
 return <main className="dashboard dark">
 <header className="topbar"><div className="brand"><div className="brand-icon"><Layers3 size={25}/></div><h1>校园数字孪生<span>CAMPUS TWIN</span></h1></div><div className="workspace-tag"><i className="status-dot"/>校园总览 <span>/</span> 三维空间</div><div className="header-end"><span className="demo-badge">演示模式</span><span className="edition">智慧校园 · V1.0</span></div></header>
 <div className="workspace"><aside className="building-panel"><div className="panel-kicker">CAMPUS EXPLORER</div><div className="panel-heading"><h2>校园建筑</h2><span>09</span></div><p className="intro">选择建筑，查看空间与运行信息</p><div className="building-list">{['公共服务','教学科研','生活配套','运动场所'].map(type=><section key={type}><h3>{type}<span>{buildings.filter(b=>b.type===type).length}</span></h3>{buildings.filter(b=>b.type===type).map(b=><button className={'building-row '+(selected.id===b.id?'active':'')} key={b.id} onClick={()=>select(b)}><Building2 size={18} style={{color:b.color}}/><span>{b.name}<small>{b.id} · {b.floors} 层</small></span><ChevronRight size={15}/></button>)}</section>)}</div><div className="model-note"><Box size={18}/><div>校园概念模型<small>几何体建筑 · 示意布局</small></div></div></aside>
 <section className="main-view"><div className="view-heading"><div><span className="panel-kicker">DIGITAL CAMPUS</span><h2>让校园，一目了然<span className="live-tag">● 场景就绪</span></h2></div><span className="coordinate">⌖ 主校区</span></div><div className="stats">{[{label:'校园建筑',value:'9',unit:'栋',icon:Building2},{label:'总建筑面积',value:'6.08',unit:'万 m²',icon:Layers3},{label:'校园人数',value:'3,054',unit:'人',icon:Users}].map(s=><div className="stat" key={s.label}><s.icon size={19}/><div><span>{s.label}</span><strong>{s.value}<small>{s.unit}</small></strong></div></div>)}</div>
 <CampusScene api={api} onSelect={setSelected}/><div className="scene-topline"><span><i className="status-dot"/>3D 场景</span><span>校园示意模型</span></div><div className="compass"><Compass size={35} strokeWidth={1}/><span>N</span></div><div className="view-tools"><button onClick={()=>api.current?.view()} title="恢复默认视角" aria-label="恢复默认视角"><RotateCcw size={19}/></button><button onClick={()=>api.current?.view(true)} title="俯视校园" aria-label="俯视校园"><ArrowUp size={19}/></button><div/><button onClick={()=>api.current?.zoom(.85)} aria-label="放大">+</button><button onClick={()=>api.current?.zoom(1.18)} aria-label="缩小">−</button><div/><button onClick={()=>{const el=document.querySelector('.main-view');if(document.fullscreenElement)document.exitFullscreen();else el?.requestFullscreen?.().catch(()=>{});}} title="全屏查看" aria-label="全屏查看"><Maximize size={18}/></button></div>
 <div className="scene-bottom"><div className="legend">{[['#68b7ed','教学科研'],['#4be2ca','公共服务'],['#b1a2f3','生活配套'],['#edbc70','运动场所']].map(([c,t])=><span key={t}><i style={{background:c}}/>{t}</span>)}</div><p>拖动旋转 <b>·</b> 滚轮缩放 <b>·</b> 右键平移</p></div></section>
 <aside className="detail-panel"><div className="detail-head"><span className="panel-kicker">BUILDING INSIGHT</span><span className="tiny-pill">已选中</span></div><div className="building-title"><div className="detail-icon" style={{color:selected.color}}><Building2 size={27}/></div><div><h2>{selected.name}</h2><p>{selected.id} / {selected.type}</p></div></div><div className="normal"><i className="status-dot"/>运行正常<span>模拟状态</span></div><div className="detail-grid"><div>建筑面积<strong>{selected.area.toLocaleString()}<small>m²</small></strong></div><div>建筑楼层<strong>{selected.floors}<small>层</small></strong></div><div>建筑高度<strong>{selected.h}<small>m</small></strong></div><div>当前人数<strong>{selected.people}<small>人</small></strong></div></div><div className="energy-head"><h3><Zap size={16}/> 今日用电</h3><span>模拟数据</span></div><div className="energy-value">{Math.round(selected.area*.14).toLocaleString()}<small>kWh</small><span>↓ 6.2%</span></div><div className="bar-chart" aria-label="模拟的全天用电趋势">{[16,13,11,12,18,32,49,68,73,66,60,69,80,65,71,54,48,55,41,30,24,20,17,14].map((h,i)=><div key={i} style={{height:h+'%',opacity:i>17?.32:1}}/>)}</div><div className="chart-axis"><span>00:00</span><span>12:00</span><span>24:00</span></div><div className="scene-settings"><h3><Eye size={16}/> 场景设置</h3><div><span>建筑名称</span><Switch checked={labels} onCheckedChange={v=>{setLabels(v);api.current?.labels(v);}} aria-label="显示建筑名称"/></div><div><span>自动旋转</span><Switch checked={rotate} onCheckedChange={v=>{setRotate(v);api.current?.rotate(v);}} aria-label="自动旋转"/></div><div><span>夜间模式</span><Switch checked={night} onCheckedChange={v=>{setNight(v);api.current?.night(v);}} aria-label="夜间模式"/></div></div><div className="data-notice"><Activity size={16}/><p>当前为演示场景，建筑与运行数据均为模拟数据，尚未连接实时设备。</p></div></aside></div><footer><span><GraduationCap size={15}/>智慧校园空间管理平台</span><span>THREE.JS · WebGL 三维引擎</span></footer>
 </main>;
}

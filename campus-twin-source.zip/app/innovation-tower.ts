import * as THREE from 'three';

// Reference-derived stylization: inferred dimensions, not a surveyed BIM model.
const smooth=(v:number)=>{const t=THREE.MathUtils.clamp(v,0,1);return t*t*(3-2*t);};
const N=128;
export function createInnovationTower(detail=true){
 const root=new THREE.Group();root.name='赛马会创新楼';
 const white=new THREE.MeshStandardMaterial({color:'#ebece5',roughness:.42,metalness:.12});
 const glass=new THREE.MeshPhysicalMaterial({color:'#345969',roughness:.22,metalness:.42,clearcoat:.8});
 const stone=new THREE.MeshStandardMaterial({color:'#b2b9b4',roughness:.86});
 const dark=new THREE.MeshStandardMaterial({color:'#223b44',roughness:.4,metalness:.4});
 const roofMat=new THREE.MeshStandardMaterial({color:'#cdd3cf',roughness:.7});
 const parts:THREE.Group[]=[];
 function part(name:string){const g=new THREE.Group();g.name=name;g.userData.part=name;root.add(g);parts.push(g);return g;}
 function mesh(geometry:THREE.BufferGeometry,material:THREE.Material,parent:THREE.Group){const m=new THREE.Mesh(geometry,material);m.castShadow=true;m.receiveShadow=true;m.userData.part=parent.name;parent.add(m);return m;}
 function box(w:number,h:number,d:number,x:number,y:number,z:number,mat:THREE.Material,parent:THREE.Group){const m=mesh(new THREE.BoxGeometry(w,h,d),mat,parent);m.position.set(x,y,z);return m;}
 // Closed, asymmetric elongated footprints: two lobes joined at the high end.
 const footprints=[
 [[-29,-9],[-26,-15],[-9,-17],[16,-15],[30,-9],[32,-4],[23,0],[2,1],[-20,-3]],
 [[-31,7],[-25,1],[-10,-1],[10,-2],[27,-3],[30,1],[19,9],[-1,16],[-20,16],[-29,12]],
 ];
 const curves=footprints.map(points=>new THREE.CatmullRomCurve3(points.map(([x,z])=>new THREE.Vector3(x,0,z)),true,'centripetal'));
 const roof=(x:number,wing:number)=>wing===0?35+12*smooth((x+14)/40):26+15*smooth((x+18)/46);
 const point=(wing:number,t:number,f:number,expand=0)=>{const p=curves[wing].getPoint(t);const centerZ=wing===0?-7:7;const bulge=1+.033*Math.sin(f*Math.PI)-.055*f*f;return new THREE.Vector3(p.x*bulge+Math.sign(p.x)*expand,6+f*(roof(p.x,wing)-6),centerZ+(p.z-centerZ)*bulge+(p.z>centerZ?expand:-expand));};
 // A closed loft has real sidewalls and caps; ribbons follow the same envelope.
 function loft(wing:number,from:number,to:number,expand:number,parent:THREE.Group,material:THREE.Material){
  const pos:number[]=[],ind:number[]=[];const rings=5;
  for(let j=0;j<=rings;j++)for(let i=0;i<N;i++){const p=point(wing,i/N,THREE.MathUtils.lerp(from,to,j/rings),expand);pos.push(p.x,p.y,p.z);}
  for(let j=0;j<rings;j++)for(let i=0;i<N;i++){const a=j*N+i,b=j*N+(i+1)%N;ind.push(a,b,a+N,b,b+N,a+N);}
  for(const j of (material===glass?[]:[0,rings])){
   const outline=[];for(let i=0;i<N;i++)outline.push(new THREE.Vector2(pos[(j*N+i)*3],pos[(j*N+i)*3+2]));
   const fraction=j===0?from:to,bulge=1+.033*Math.sin(fraction*Math.PI)-.055*fraction*fraction;
   function triangle(a:THREE.Vector2,b:THREE.Vector2,c:THREE.Vector2,depth:number){
    if(depth){const ab=a.clone().lerp(b,.5),bc=b.clone().lerp(c,.5),ca=c.clone().lerp(a,.5);triangle(a,ab,ca,depth-1);triangle(ab,b,bc,depth-1);triangle(ca,bc,c,depth-1);triangle(ab,bc,ca,depth-1);return;}
    const start=pos.length/3;for(const v of [a,b,c]){const x=(v.x-Math.sign(v.x)*expand)/bulge;pos.push(v.x,6+fraction*(roof(x,wing)-6),v.y);}ind.push(...(j===0?[start+2,start+1,start]:[start,start+1,start+2]));
   }
   for(const f of THREE.ShapeUtils.triangulateShape(outline,[]))triangle(outline[f[0]],outline[f[1]],outline[f[2]],2);
  }
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));for(let i=0;i<ind.length;i+=3){[ind[i+1],ind[i+2]]=[ind[i+2],ind[i+1]];}geo.setIndex(ind);geo.computeVertexNormals();return mesh(geo,material,parent);
 }
 const base=part('雕塑基座');
 const shape=new THREE.Shape();shape.moveTo(-33,-17);shape.quadraticCurveTo(-38,0,-30,17);shape.quadraticCurveTo(-15,21,3,17);shape.lineTo(32,3);shape.quadraticCurveTo(39,-8,28,-16);shape.lineTo(-33,-17);
 const baseGeo=new THREE.ExtrudeGeometry(shape,{depth:5.7,bevelEnabled:true,bevelSize:.7,bevelThickness:.5,bevelSegments:3,steps:1,curveSegments:20});baseGeo.rotateX(Math.PI/2);baseGeo.translate(0,6,0);mesh(baseGeo,stone,base);
 const rear=part('高侧翼楼'),front=part('低侧翼楼'),cladding=part('流线形立面'),roofGroup=part('层叠屋面'),entry=part('入口雨棚');
 [rear,front].forEach((g,k)=>loft(k,0,1,0,g,glass));
 if(detail){
  for(let wing=0;wing<2;wing++){
   const floors=wing===0?15:12;
   for(let i=0;i<=floors;i++){const f=i/floors;loft(wing,Math.max(0,f-.017),Math.min(1.012,f+.006),.58,cladding,white);}
   // Roof fascia is a solid shallow shell, with recessed plant wells on the high wing.
   loft(wing,1,1.016,.2,roofGroup,white);
   const mullionGeom=new THREE.BoxGeometry(.105,1,.11);
   const mullions=new THREE.InstancedMesh(mullionGeom,dark,80*floors);let index=0;const matrix=new THREE.Matrix4(),q=new THREE.Quaternion(),scale=new THREE.Vector3();
   for(let i=0;i<80;i++)for(let j=0;j<floors;j++){const a=point(wing,i/80,(j+.2)/floors,.04),b=point(wing,i/80,(j+.83)/floors,.04);scale.set(1,a.distanceTo(b),1);matrix.compose(a.clone().lerp(b,.5),q,scale);mullions.setMatrixAt(index++,matrix);}mullions.instanceMatrix.needsUpdate=true;mullions.userData.part='流线形立面';cladding.add(mullions);
   // Subtle transverse seams articulate the broad sloping roof.
   for(let x=-20;x<25;x+=5){const z=wing===0?-8:7;const y=6+1.017*(roof(x,wing)-6);box(.055,.035,wing===0?10:9,x,y+.05,z,roofMat,roofGroup);}
  }
  for(let x=13;x<26;x+=5){const y=roof(x,0)+.55;box(3.9,.25,5,x,y,-8,dark,roofGroup);box(3.3,.25,4.4,x,y+.04,-8,roofMat,roofGroup);for(let z=-9;z<-6;z+=1.8){const fan=mesh(new THREE.CylinderGeometry(.65,.65,.2,16),dark,roofGroup);fan.position.set(x,y+.3,z);}}
  // Front folded entrance canopy: a tapered wedge connected back into the lower wing.
  const vertices=[[-22,10,10],[-3,11.5,12],[1,2,29],[-8,2,30],[-28,10,24],[-22,8.7,10],[-3,10.2,12],[1,.8,29],[-8,.8,30],[-28,8.7,24]];
  const canopyGeo=new THREE.BufferGeometry();canopyGeo.setAttribute('position',new THREE.Float32BufferAttribute(vertices.flat(),3));canopyGeo.setIndex([0,1,4,1,2,4,2,3,4,5,9,6,6,9,7,7,9,8,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,8,3,8,4,4,8,9,4,9,0,0,9,5]);canopyGeo.computeVertexNormals();mesh(canopyGeo,white,entry);
  box(10,7,.45,-16,4.2,15,dark,entry);for(let x=-20;x<=-12;x+=2)box(.12,7,.55,x,4.2,15.1,white,entry);
  for(let i=0;i<9;i++)box(19,.3*(9-i),1.1,-16,.15*(9-i),18+i*1.1,stone,entry);
 }
 root.userData.parts=parts;root.userData.approximate=true;return root;
}



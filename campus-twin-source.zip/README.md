# 校园数字孪生平台

基于 Three.js、React 和 Vinext 的网页应用。包含 9 栋几何体建筑、校园道路、广场、绿化和运动场。

## 运行

需要 Node.js 22.13 或更高版本及 pnpm。

```sh
pnpm install
pnpm dev
```

打开终端显示的本地网址（默认 http://localhost:3000）。

```sh
pnpm build
```

静态网站生成在 `dist/client`，可部署至静态网页服务器。通过 HTTP 打开，不能直接双击 HTML 使用 file 协议。

## 使用

- 拖动旋转，滚轮缩放，右键平移；触屏支持单指旋转、双指缩放/平移。
- 点击建筑或左侧列表查看详情。
- 右侧工具支持复位、俯视、放大、缩小、全屏。
- 场景设置支持建筑标签、自动旋转和夜间模式。

建筑参数集中在 `app/page.tsx` 的 buildings 数组，可修改布局位置、尺寸、名称和属性。全部运行指标为模拟数据，尚未接入真实设备。需要支持 WebGL 的浏览器。

可选 WebMCP 建筑选择工具已实现；当前环境未提供对应验证上下文，未作运行验证。

## GitHub Pages

GitHub Pages 使用独立的 Vite 静态入口，复用同一套校园组件，无需服务器。

1. 将项目上传到自己的 GitHub 仓库。
2. 仓库 Settings → Pages → Source 选择 GitHub Actions。
3. 推送 main/master 分支，或手动运行 Deploy campus to GitHub Pages 工作流。

工作流自动读取仓库对应的基础路径，构建并发布 `dist/pages`。部署成功后在 Actions 的部署记录获取网址。无需填写个人访问令牌。
